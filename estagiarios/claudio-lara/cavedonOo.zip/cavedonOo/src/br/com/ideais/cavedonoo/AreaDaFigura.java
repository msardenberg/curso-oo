package br.com.ideais.cavedonoo;

abstract class AreaDaFigura implements CalculoArea{
	
}
