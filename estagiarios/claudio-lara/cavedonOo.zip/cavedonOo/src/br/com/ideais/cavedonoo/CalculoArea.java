package br.com.ideais.cavedonoo;

import java.util.ArrayList;

public interface CalculoArea {

	double calculoArea (ArrayList<Double> lista);

}	

	
